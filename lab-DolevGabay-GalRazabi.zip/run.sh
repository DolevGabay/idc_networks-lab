cd Sources
java Program
